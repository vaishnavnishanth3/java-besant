package Supply_chain_management;

public class Index
{
    public static void main(String[] args)
    {
        Login_signup.intro();
    }
}
